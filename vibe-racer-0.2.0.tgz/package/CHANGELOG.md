# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.2.0] - 2026-04-11

### Changed

- Renamed package from `jugglr-vibe` to `vibe-racer`
- Rebranded around the F1/Rally racing metaphor: project = car, stage = lap, human checkpoint = pit stop, agent handler = race engineer
- Renamed CLI commands: `run` → `drive`, `chat` → `radio`, `status` → `pitwall`
- README, docs, and pitch rewritten in racing voice
- Logo assets consolidated under `docs/public/`; repo-root copies removed

### Removed

- Old CLI command names `run`, `chat`, `status` (no aliases kept — clean break, this rename ships pre-release)

## [0.1.0] - 2026-03-31

### Added

- 5-stage development pipeline: objective, product, design, plan, execute
- CLI commands: `init`, `new`, `status`, `run`, `chat`
- Claude Code SDK integration with role-based personas (Product Designer, Software Architect, Software Engineer)
- Two-layer security guard: `allowedTools` per stage + `canUseTool` callback
- Path containment (project cwd + /tmp, symlink-aware)
- Bash command blocklist (19 entries) with interpreter-aware network detection
- Obfuscation heuristics for base64 encoding and character code construction
- Pre-commit secret scanning (filename + content pattern matching)
- Append-only audit log for guard denials
- Trivial task flagging (skip product + design stages)
- Follow-up question rounds (max 3 rounds, 5-6 questions per round)
- Pre-filled answers: agent recommends, human edits disagreements only
- Git-native workflow: local branches, automatic commits, no push
- Example task included (`plans/0001_example-todo-app/`)
- VitePress documentation site
